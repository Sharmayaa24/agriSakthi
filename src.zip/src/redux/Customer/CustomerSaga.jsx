import { call, put, takeLatest } from "redux-saga/effects";
import { CUSTOMER_ADD_FAILURE, CUSTOMER_ADD_PROGRESS, CUSTOMER_ADD_SUCCESS } from "./CustomerType";
import { addCustomerAPI } from "./CustomerEffects";



function* addCustomer({ payload }) {
  
    try {
        const { data } = yield call(customerAddEffect, payload);
        console.log(data);
        yield put(addCustomerSuccess({
          data: data,
          message: data['message'],
          success: true,
        }))
    } catch (err) {
      console.log(err,"error")
        yield put(addCompleteFailure(err)); 
    }
  }
export default function* customerSaga() {
    yield takeLatest(CUSTOMER_ADD_PROGRESS, addCustomer);
}