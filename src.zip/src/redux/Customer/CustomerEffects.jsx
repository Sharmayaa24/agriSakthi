import axios from "axios";

const authInstance = axios.create({
  baseURL: 'http://154.61.173.102:3006',
  headers: { 'content-type': 'application/x-www-form-urlencoded' },
});

const accessToken = localStorage.getItem('accessToken');
console.log(accessToken);

authInstance.interceptors.request.use(config => {
  config.headers['Content-Type'] = 'application/x-www-form-urlencoded';
  config.headers['Authorization'] = `Bearer ${accessToken}`;
  return config;
}, error => {
  return Promise.reject(error);
});

authInstance.interceptors.response.use(response => {
  return response;
}, error => {
  if (error.response) {
    console.log(error.response.data.errorFields.contact, "hello")
    console.log(error.response.data, "hello")
    return Promise.reject(error.response.data.errorFields.email || error.response.data.errorFields.contact || error.response.data);
  }
  return Promise.reject(error);
});

export const addCustomerAPI = (formData) => {
  return authInstance.post('/customers/insertcustomer', formData);
};