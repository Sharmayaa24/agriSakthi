import { CUSTOMER_ADD_FAILURE, CUSTOMER_ADD_PROGRESS, CUSTOMER_ADD_SUCCESS } from "./CustomerType";


export const addCustomerProgress = (payload) => {
    return {
    type: CUSTOMER_ADD_PROGRESS,
    payload,
    };
};

export const addCustomerSuccess = (payload) => {
    return {
    type: CUSTOMER_ADD_SUCCESS,
    payload,
    };
};

export const addCustomerFailure = (payload) => {
    return {
    type: CUSTOMER_ADD_FAILURE,
    payload,
    };
};