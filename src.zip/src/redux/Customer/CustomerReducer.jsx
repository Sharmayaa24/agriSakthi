import { CUSTOMER_ADD_FAILURE, CUSTOMER_ADD_PROGRESS, CUSTOMER_ADD_SUCCESS } from "./CustomerType";

const initialState={
    addCustomerState:{
        inProgress: false,
        success: false,
        error: false,
        data: [],
    }
}

export const CustomerReducer= (state = initialState, action) => {
    switch (action.type) {
        case CUSTOMER_ADD_PROGRESS:
            return {
                ...state,
                addCustomerState: {...state.addCustomerState,
                    inProgress: true,
                    success: false,
                    error:false,
                }
            }
        case CUSTOMER_ADD_SUCCESS:
            return {
                ...state,
                addCustomerState:{...state.addCustomerState,
                    inProgress: false,
                    success: true,
                    error:false,
                    data:action.payload
                }
            }
            case CUSTOMER_ADD_FAILURE:
                return {
                    ...state,
                    addCustomerState:{...state.addCustomerState,
                        inProgress: false,
                        success: false,
                        error:true,
                        }
                    }
            default:return state;
    }
}