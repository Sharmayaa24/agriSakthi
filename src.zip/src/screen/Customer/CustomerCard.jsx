import React from 'react'

const CustomerCard = () => {
  return (
    <div>
      
    </div>
  )
}

export default CustomerCard
