import RouteComponent from "./Route/route";
function App() {
  return (
    <div>
      <RouteComponent />
    </div>
  );
}

export default App;
